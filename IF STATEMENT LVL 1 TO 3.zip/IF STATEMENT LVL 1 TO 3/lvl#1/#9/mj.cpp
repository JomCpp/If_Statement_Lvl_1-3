#include <iostream>

using namespace std; 

int main()
{
	int att , toh , toa ;
	char conformation ;
	cout << " enter the total number of classes held:"<< endl;
	cin >> toh ;
	cout << " enter the total number of classes attended: "<< endl;
	cin >> toa;
	
	att=  toa * 100 / toh;
	
	cout << " is there any medical condition, comment Y or N "<< endl ;
	cin >> conformation;
	
	if ( att >= 75)
	{
		cout << " allowed to sit in the class "<< endl;
	}
	else if (att <= 75 && conformation == 'Y')
	{
		cout <<" allowed to sit in the class "<< endl;
	}
	else
	{
		cout << " not allowed to sit in the class"<< endl;
	}
	return 0;
}
	