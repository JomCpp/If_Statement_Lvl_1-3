#include <iostream>

using namespace std;

int main ()
{
	int grade;
	cout <<"enter grade:"<< endl ;
	cin >> grade ;
	if (grade <= 25)
	{
		cout << "F"<<endl;
	}
	else if (grade <= 45)
	{
		cout << "E"<<endl;
	}
	else if (grade <= 50)
	{
		cout << "D"<<endl;
	}
	else if (grade <= 60)
	{
		cout << "C"<<endl;
	}
	else if (grade <= 80)
	{
		cout << "B"<<endl;
	}
	if (grade > 80)
	{
		cout << "A"<<endl;
	}
	return 0;
}