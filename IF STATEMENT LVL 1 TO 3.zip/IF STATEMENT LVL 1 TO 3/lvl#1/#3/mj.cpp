#include <iostream>

using namespace std;

int main ()
{
	int quantity;
	float rate = 0.1;
	float total;
	cout <<"enter quantity: "<< endl;
	cin >> quantity;
	total = quantity * 100;
	if (total > 1000)
		cout <<"your total expense after discounted is: "<< total - rate << endl;
	else
		cout <<"your total cost is: "<< total << endl;
	return 0;
}