#include <iostream>

using namespace std;

int main ()
{
	int num1 , num2 , greatest;
	cout <<"enter two numbers: "<< endl;
	cin >> num1 >> num2 ;
	
	greatest = num1;
	if (num2 > greatest)
		greatest = num2;
		cout <<"the greatest is: "<< greatest << endl;
	return 0;
}