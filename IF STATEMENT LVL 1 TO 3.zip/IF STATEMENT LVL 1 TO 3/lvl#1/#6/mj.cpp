#include <iostream>

using namespace std;

int main ()
{
	int p1, p2, p3;
	cout <<"please enter the ages of p1 ,p2 end p3: "<< endl;
	cin >> p1 >> p2 >> p3 ;
	if ((p1>p2)&& (p1>p3))
	{
		cout <<"p1 is the oldest "<<endl;
	}
	else
	{
		cout << "p1 is the youngest"<< endl;
	}
	if ((p2>p1)&& (p2>p3))
	{
		cout <<"p2 is the oldest "<<endl;
	}
	else
	{
		cout << "p2 is the youngest"<< endl;
	}
	if ((p3>p1)&& (p3>p2))
	{
		cout <<"p3 is the oldest "<<endl;
	}
	else
	{
		cout << "p3 is the youngest"<< endl;
	}
	return 0;
}