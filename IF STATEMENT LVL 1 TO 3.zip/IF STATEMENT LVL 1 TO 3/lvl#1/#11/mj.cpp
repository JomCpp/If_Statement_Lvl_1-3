#include <iostream>

using namespace std;

int main()
{
	char character;
	cout <<" enter any character: "<< endl;
	cin >> character;
	
	if (character >= 65&& character<=90)
		cout <<"you entered an uppercase character "<< endl;
	else if (character >= 48 && character <= 57)
		cout <<"you entered a digit"<< endl;
	else if (character >= 97 && character <= 122)
		cout <<"you entered a lowercase character"<< endl;
	else
		cout <<"you entered a special character"<< endl;
	return 0;
}