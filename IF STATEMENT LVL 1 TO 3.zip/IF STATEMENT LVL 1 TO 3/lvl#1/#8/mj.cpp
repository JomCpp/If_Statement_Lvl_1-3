#include <iostream>

using namespace std;

int main()
{
	float a , b;
	float c;
	cout<<"enter num of class held: ";
	cin>> a;
	cout<<"enter num of classes attended: ";
	cin>> b;

	c = (b / a)* 100;
	if (c >= 75)
		cout <<" youre allowed to sit in: "<<c <<"%"<<endl;
	else 
		cout <<"sorry youre not allowed to sit in: "<<c <<"%"<<endl;
	return 0;
}