#include <iostream>

using namespace std;

int main ()
{
	int x , y;
	cout <<"enter length:"<< endl;
	cin >> x;
	cout <<"enter breadth:"<< endl;
	cin >> y;
	if (x == y)
		cout <<"its a square :)"<< endl;
	else 
		cout <<"its not a square :( "<< endl;
	return 0;
}
