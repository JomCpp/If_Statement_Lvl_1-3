#include <iostream>

using namespace std;

int main ()
{
	int x;
	cout <<" input a number: " << endl;
	cin >> x;
	if (x < 0)
	{
		cout << x*-1;
	}
	else
	{
		cout <<x;
	}
	return 0;
}