#include <iostream>

using namespace std;

int main ()
{
	int salary , year , bonus ;
	cout<<" enter your salary: ";
	cin >> salary ;
	cout<<" enter year of service: ";
	cin >> year ;
	if (year > 5)
	{
		bonus =  salary * 5 / 100;
		cout<< "your bonus amount:"<< bonus << endl;
	}
	else
	{
		cout <<" sorry you dont have any bunos amount, thanks for your service :) "<< endl;
	}
	return 0;
}