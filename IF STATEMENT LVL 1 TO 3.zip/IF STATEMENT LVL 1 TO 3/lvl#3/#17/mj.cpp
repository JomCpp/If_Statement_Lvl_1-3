#include <iostream>

using namespace std;

int main()
{
	int n1 , n2 , n3 , n4 ;
	int greatest;
	cout <<"please enter a four numbers: "<< endl ;
	cin >> n1 >> n2 >> n3 >> n4 ;
	
	greatest = n1;
	if ((n1 > n2)&& (n1 > n3) && ( n1 > n4))
	{
		cout << " the greatest is: "<< greatest << endl;
	}
	greatest = n2;
	if ((n2 > n1)&& (n2 > n3) && ( n2 > n4))
	{
		cout << " the greatest is: "<< greatest << endl;
	}
	greatest = n3;
	if ((n3 > n1)&& (n3 > n2) && ( n3 > n4))
	{
		cout << " the greatest is: "<< greatest << endl;
	}
	greatest = n4;
	if ((n4 > n1)&& (n4 > n2) && ( n4 > n3))
	{
		cout << " the greatest is: "<< greatest << endl;
	}
	return 0;
}
