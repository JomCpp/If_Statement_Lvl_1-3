#include <iostream>

using namespace std; 

int main()
{
	int numd;
	cout <<" enter a number of days between 1-7: "<< endl ;
	cin >> numd;
	
	if (numd == 1)
		cout << " Monday "<< endl;
	else if (numd == 2)
		cout << " Tuesday "<< endl;
	else if (numd == 3)
		cout << " Wednesday"<< endl;
	else if (numd == 4)
		cout << " Thursday "<< endl;
	else if (numd == 5)
		cout << " Friday "<< endl;
	else if (numd == 6)
		cout << " Saturday "<< endl;
	else if (numd == 7)
		cout << " Sunday "<< endl;
	if (numd < 1 || numd > 7)
		cout << " ERROR "<< endl;
	return 0;
}
	