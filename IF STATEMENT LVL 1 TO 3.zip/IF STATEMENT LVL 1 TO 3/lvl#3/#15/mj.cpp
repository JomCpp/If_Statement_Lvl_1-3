#include <iostream>

using namespace std; 

int main()
{
	int negnum;
	cout <<" Enter a number: ";
	cin >> negnum;
	
	if (negnum < 0 )
	{
		cout << negnum << " is number negative number. "<< endl;
		cout << " new value is: "<< -(negnum) << endl;
	}
	else if (negnum > 0 )
	{
		cout << negnum << " is number positive number. "<< endl;
		cout << " new value is: " << -(negnum) << endl;
	}
	else if (negnum == 0)
		cout << negnum << " is not positive or negative number. "<< endl;
	return 0;
}
	