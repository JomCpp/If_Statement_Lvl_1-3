#include <iostream>
#include <iomanip>

using namespace std; 

int main()
{
	float number1 , number2 ;
	cout <<" Enter two decimal number: "<< endl ;
	cin >> number1 >> number2 ;
	cout << setprecision (4);
	cout << number1 << endl;
	cout << number2 << endl;
	
	if (number1 == number2)
		cout << " They are the same";
	else 
		cout <<"they are different";
	return 0;
}
