#include <iostream>

using namespace std; 

int main()
{
	float a;
	cout << " Enter a number with decimals: ";
	cin >> a;
	
	int b = (int) a;
	
	if (b < 0)
	{
		cout << b<< endl;
		cout << " Negative number "<< endl;
		if (b <1){
			cout << "small ";
		}
		else if (b > 1000000){
			cout << "larger" ;
		}
	}
	else if ( b > 0) {
		cout << b << endl;
		cout << " positive number "<< endl;
		if (b < 1 ){
			cout << "small";
		}
		else if (b > 1000000){
			cout << "larger";
		}
	}
	else if (b == 0){
		cout << b << endl;
		cout << " zero "<< endl;
	}
	return 0;
}
	