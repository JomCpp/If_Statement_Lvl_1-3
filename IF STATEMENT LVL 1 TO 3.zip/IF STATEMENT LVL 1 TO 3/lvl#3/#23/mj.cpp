#include <iostream>

using namespace std;

int main ()
{
	int  no1 , no2 ;
	cout <<" enter a year";
	cin >> no1;
	
	if ((no1 % 400 == 0)||((no1 % 4 == 0)&& (no1 % 100 != 0))){
		cout << no1 << " is a leap year" << endl;
		no2 = no1 % 100 ;
		if (no2 % 3 == 0 ){
			cout << " This leap year is divisible by 3";
		}
		else {
			cout << "the leap year is NOT divisible by 3";
		}
	}
	else {
		cout << no1 << " is NOT a leap year " << endl ;
		if (no1 % 2 == 0){
			cout << " This year is even. ";
		}
		else{
			cout << " This year is odd. ";
		}
	}
	return 0;
}
