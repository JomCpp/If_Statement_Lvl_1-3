#include <iostream>

using namespace std;

int main()

{
	int age;
	char gender , ms , m , f , y , n ;
	cout <<"enter age of employee"<< endl;
	cin>> age;
	cout <<"enter gender of employee"<< endl;
	cin>> gender;
	cout <<"enter marital satatus of employee"<< endl;
	cin>> ms;
	
	if (gender == 'f')
	{
		cout <<"employee will only work in urban areas "<< endl;
	}
	if (gender=='m')
	
	if (age>=20 & age <=40)
	{
		cout <<" the employee will worn any where"<< endl;
	}
	else if (age >40 & age< 60)
	{
		cout <<" the employee will only work in urban areas "<< endl;
	}
	else
	{
		cout << " error "<< endl;
	}
	return 0;
}